// Referencia de la base de datos de Firebase
var inventoryRef = database.ref('inventory');

// listener  de envío de formulario
document.getElementById('inventory-form').addEventListener('submit', submitForm);

// Enviar formulario
function submitForm(event) {
  event.preventDefault();

  // Obtener valores de formulario
  var id = getInputValue('id');
  var name = getInputValue('name');
  var price = getInputValue('price');
  var quantity = getInputValue('quantity');
  var description = getInputValue('description');
  var notes = getInputValue('notes');

  // Guardar elemento
  saveItem(id, name, price, quantity, description, notes);

  // Limpiar form
  document.getElementById('inventory-form').reset();
}

// Get form input value
function getInputValue(id) {
  return document.getElementById(id).value;
}

// Guardar elemento en la base de datos
function saveItem(id, name, price, quantity, description, notes) {
  var newItemRef = inventoryRef.child(id);
  newItemRef.set({
    name: name,
    price: price,
    quantity: quantity,
    description: description,
    notes: notes
  });
}

 // Eliminar elemento de la base de datos
 function deleteItem(id) 
 {
  inventoryRef.child(id).remove();
 } 

  // Cargar artículos de inventario
  inventoryRef.on('value', function(data) {
    var inventoryList = document.getElementById('inventory-list');
    inventoryList.innerHTML = '';
    data.forEach(function(item) {
    var key = item.key;
    var name = item.val().name;
    var price = item.val().price;
    var quantity = item.val().quantity;
    var description = item.val().description;
    var notes = item.val().notes;
  
    // agregar articulo para mostrarlo en pantalla
  var itemElement = document.createElement('li');
  itemElement.innerHTML = '<strong>ID:</strong> ' + key + '<br>' +
                          '<strong>Nombre:</strong> ' + name + '<br>' +
                          '<strong>Precio:</strong> ' + price + '<br>' +
                          '<strong>Cantidad:</strong> ' + quantity + '<br>' +
                          '<strong>Descripcion:</strong> ' + description + '<br>' +
                          '<strong>Notas:</strong> ' + notes;
  addItemDeleteButton(itemElement, key);
  inventoryList.appendChild(itemElement);
  });
   // Agregar botón de eliminar en cada artículo de inventario
   function addItemDeleteButton(itemElement, id) {
    var deleteButton = document.createElement('button');
    deleteButton.innerHTML = 'Eliminar';
    deleteButton.addEventListener('click', function() {
    deleteItem(id);
    });
    itemElement.appendChild(deleteButton);
    }
  });


